Advanced Card Systems Ltd.




Contents
----------------

   1. Release notes
   2. History
   3. File Content
   4. Limitations
   5. Support



1. Release notes
----------------

Version: 0.1.0.1
Release date: 19/8/2008



2. History
----------------

0.1.0.0		Supports win98/ME, 2000, XP, 2003 and Vista (x86 & x64).
0.1.0.1		Added ACS PCSC JNI Library


3. File Content
----------------
a122w98.sys	1.1.6.2
acr122.inf		x.x.x.x
acr122x64.sys	1.1.6.2
acr122.cat	x.x.x.x
acr122.sys	1.1.6.2
difxapi.dll		2.0.1.0
SCBASE		4.71.1015.0
SMCLIB		4.71.1015.0
Setup64.exe	x.x.x.x
Jacspcsc.dll	x.x.x.x


4. Limitations
----------------

1) The installer cannot be called by another .exe (calling program). If you really need to do so, the .exe (calling program) must be in the same directory with setup.exe.

2) After each uninstallation, must reboot before another installation.

3) Incompatible with Proprietary driver.

4) Does not support PnP installation in Win98 and WinME.



5. Support
----------------

In case of problem, please contact ACS through:

web site: http://www.acs.com.hk/
email: info@acs.com.hk



-----------------------------------------------------------------


Copyright 
Copyright by Advanced Card Systems Ltd. (ACS) No part of this reference manual may be reproduced or transmitted in any from without the expressed, written permission of ACS. 

Notice 
Due to rapid change in technology, some of specifications mentioned in this publication are subject to change without notice. Information furnished is believed to be accurate and reliable. ACS assumes no responsibility for any errors or omissions, which may appear in this document. 





